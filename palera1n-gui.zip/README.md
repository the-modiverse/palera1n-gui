# palera1n-c GUI

## Getting the GUI up and running
1. Run `git clone https://github.com/hephaestus-ironside/palera1n-gui --recursive && cd palera1n-gui`
2. Run `python3 palera1n.py`
